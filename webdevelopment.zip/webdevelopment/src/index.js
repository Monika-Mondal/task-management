const express= require('express');
const path= require('path');
const bcrypt= require('bcrypt');
const user= require('./config');



const app= express();

//convert data into json format
app.use(express.json());
app.use(express.urlencoded({extended: false}));

//use EJS as view engine
app.set('view engine', 'ejs');

//static file
app.use(express.static("public"));

app.get("/",(req,res)=>{
    res.render("login");
});

app.get("/signup",(req,res)=>{
    res.render("signup");
});


// register user
app.post("/signup", async (req, res) => {
    try {
        const data = {
            email: req.body.email,
            password: req.body.password
        }

        // check if user already exists
        const existUser = await user.findOne({ email: data.email });

        if (existUser) {
            return res.send("Email is already exist! Try a different email");
        }

        // hash the password using bcrypt
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(data.password, saltRounds);

        // replace the original password with the hashed one
        data.password = hashedPassword;

        // insert the user into the database
        const userData = await user.create(data);
        console.log(userData);

        res.send("User registered successfully!");
    } catch (error) {
        console.error('Error registering user:', error);

        if (error.name === 'MongoError' && error.code === 11000) {
            // Duplicate key error (MongoError code for duplicate key)
            res.send("Email is already exist! Try a different email");
        } else {
            res.status(500).send(`Internal Server Error: ${error.message}`);
        }
    }
});

// register user
app.post("/login", async (req, res) => {
    try{
        const check = await user.findOne({ email: req.body.email });
        if(!check){
            res.send("User not found!");
        }

    
    //compare the password with database
    const isPassworMatch = await bcrypt.compare(req.body.password,check.password);
    if(isPassworMatch){
        res.render("home");
    }else{
        req.send("Wrong password!");
        }
    }catch{
        res.send("Wrong details!");

    }

});






const port=5003;

app.listen(port,()=>{
    console.log(`Server running on port: ${port}`);
});